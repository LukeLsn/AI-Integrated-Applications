import { serve } from '@hono/node-server';
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { timing } from 'hono/timing';
import { logger } from 'hono/logger';
import { zValidator } from '@hono/zod-validator';
import * as z from 'zod';

// NOTE: you will implement this code
import { generateFlashcards } from './flashcard-generator.js';

const app = new Hono();

app.use(logger(), timing());
app.use('/api/*', cors());

const generateSchema = z.object({
  notes: z.string().min(1, "Field 'notes' is required."),
  cards: z.number().optional().default(3),
});

app.post('/api/generate', zValidator('json', generateSchema), async (c) => {
  try {
    const { notes, cards } = await c.req.valid('json');
    const result = await generateFlashcards(notes, cards);

    return c.json(result);
  } catch (error: any) {
    console.error('Server Error:', error);
    return c.json(
      {
        error: 'Failed to generate flashcards.',
        details: error.message,
      },
      500
    );
  }
});

const port = 3000;
console.log(`🚀 Server running on http://localhost:${port}`);

serve({
  fetch: app.fetch,
  port,
});