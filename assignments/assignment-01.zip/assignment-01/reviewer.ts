import OpenAI from 'openai';
import { tools } from './tools';
import { readFileSync } from 'fs';
import { execSync } from 'child_process';
import { ChatCompletionMessageParam } from 'openai/resources/chat/completions';

const client = new OpenAI({
  baseURL: 'https://openrouter.ai/api/v1',
  apiKey: process.env.OPENROUTER_API_KEY,
});

export async function callReviewer(persona: string, content: string, debug: boolean) {
  const messages: ChatCompletionMessageParam[] = [
    { role: 'system', content: getSystemPrompt(persona) },
    { role: 'user', content: `Review this code:\n\n${content}` }
  ];

  let response = await client.chat.completions.create({
    model: 'openai/gpt-4o-mini',
    messages,
    tools: tools as any,
    temperature: 0.2,
  });

  // Handle Tool Calls (The Agentic Loop)
  while (response.choices[0].message.tool_calls) {
    const toolCall = response.choices[0].message.tool_calls[0];
    
    // Type Guard to ensure we only process function-type tool calls
    if (toolCall.type === 'function') {
      if (debug) console.error(`[${persona}] Calling ${toolCall.function.name}...`);
      
      const toolResult = await executeTool(toolCall);
      
      messages.push(response.choices[0].message);
      messages.push({ 
        role: 'tool', 
        tool_call_id: toolCall.id, 
        content: JSON.stringify(toolResult) 
      });

      response = await client.chat.completions.create({
        model: 'openai/gpt-4o-mini',
        messages,
        tools: tools as any
      });
    } else {
        break; // Exit loop if a non-function tool call appears
    }
  }

  const rawContent = response.choices[0].message.content || '[]';
  const cleanJson = rawContent.replace(/```json/g, '').replace(/```/g, '').trim();
  
  if (debug) console.error(`[${persona}] Raw Findings: ${cleanJson}`);
  
  try {
    return JSON.parse(cleanJson);
  } catch (e) {
    console.error(`[${persona}] Failed to parse JSON: ${cleanJson}`);
    return [];
  }
}

function getSystemPrompt(persona: string): string {
  const basePrompt = `You are an expert ${persona}. Return a JSON array: [{"path": "string", "line": number, "severity": "info" | "warn" | "critical", "category": "security" | "style" | "performance" | "design" | "ui", "description": "string"}]. Rules: Only output JSON. Use tools if needed.`;
  return persona === 'Security' 
    ? `${basePrompt} FOCUS: Look for secrets, SQLi, XSS, and dangerous logic.`
    : `${basePrompt} FOCUS: Look for DRY violations, naming conventions, and readability.`;
}

async function executeTool(toolCall: any) {
  const { name, arguments: args } = toolCall.function;
  const parsedArgs = JSON.parse(args);

  if (name === 'read_file') {
    try {
      const { file_path } = parsedArgs;
      return readFileSync(file_path, 'utf-8').slice(0, 2000);
    } catch (e) {
      return "Error: Could not read file.";
    }
  }

  if (name === 'ripgrep') {
    try {
      return execSync(`rg "${parsedArgs.search_pattern}"`).toString();
    } catch (e) {
      return "No matches found.";
    }
  }
}