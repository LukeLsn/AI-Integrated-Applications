import 'dotenv/config';
import path from 'path';
import dotenv from 'dotenv';
import { callReviewer } from './reviewer';
import { judge } from './judge';
import fs from 'fs';
import { execSync } from 'child_process';

// Load .env from 3 directories up as requested
dotenv.config({ path: path.resolve(__dirname, '../../../.env') });

const args = process.argv.slice(2);
const isDebug = args.includes('--debug');
const fileFlagIndex = args.indexOf('--file');
const fileName = fileFlagIndex !== -1 ? args[fileFlagIndex + 1] : null;

async function runReview() {
  let inputData: string;

  // 1. Determine Input Mode
  if (fileName) {
    if (!fs.existsSync(fileName)) {
      console.error(`Error: File ${fileName} not found.`);
      process.exit(1);
    }
    inputData = fs.readFileSync(fileName, 'utf-8');
  } else {
    // Git Mode
    try {
      inputData = execSync('git diff --staged').toString();
      if (!inputData.trim()) {
        console.log("No staged changes found to review.");
        process.exit(0);
      }
    } catch (e) {
      console.error("Error: Not a git repository or no changes staged.");
      process.exit(1);
    }
  }

  // 2. Parallel Reviews
  const [report1, report2] = await Promise.all([
    callReviewer('Security', inputData, isDebug),
    callReviewer('Maintainability', inputData, isDebug)
  ]);

  // 3. Synthesis
  const finalReport = await judge(report1, report2);
  
  // 4. Output
  const outputFilename = `review-${new Date().toISOString().replace(/:/g, '-')}.html`;
  fs.writeFileSync(outputFilename, finalReport);
  console.log(`Review complete. Report saved to ${outputFilename}`);
}

runReview().catch(console.error);