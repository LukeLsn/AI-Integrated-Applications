import OpenAI from 'openai';

// Assuming you have your client initialized in a shared config or passed in
const client = new OpenAI({
  baseURL: 'https://openrouter.ai/api/v1',
  apiKey: process.env.OPENROUTER_API_KEY,
});

export async function judge(review1: any[], review2: any[]): Promise<string> {
  const combinedFindings = [...review1, ...review2];
  
  const systemPrompt = `
    You are an expert Lead Developer. Your task is to act as a final judge for automated code reviews.
    1. De-duplicate findings.
    2. Remove false positives or low-quality suggestions.
    3. Output ONLY valid HTML5. Do not include markdown formatting (like \`\`\`html), 
       do not include conversational text, and do not include explanations.
    4. Use an embedded <style> block for a clean, modern, professional look.
  `;

  const completion = await client.chat.completions.create({
    model: 'anthropic/claude-3.5-sonnet',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Synthesize these code review findings into an HTML report:\n${JSON.stringify(combinedFindings)}` }
    ]
  });

  const rawHtml = completion.choices[0].message.content || '<h1>No issues found.</h1>';
  
  // Clean potential markdown code blocks if the LLM ignores instructions
  return rawHtml.replace(/```html/g, '').replace(/```/g, '').trim();
}