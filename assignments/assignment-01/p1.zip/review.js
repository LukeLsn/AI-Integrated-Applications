#!/usr/bin/env node
const { execSync } = require('child_process');
const path = require('path');

// Execute index.ts using the tsx package from node_modules
const args = process.argv.slice(2).join(' ');
try {
  execSync(`npx tsx index.ts ${args}`, { stdio: 'inherit' });
} catch (error) {
  process.exit(error.status || 1);
}